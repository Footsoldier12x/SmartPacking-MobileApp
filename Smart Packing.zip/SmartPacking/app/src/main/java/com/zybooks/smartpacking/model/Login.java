package com.zybooks.smartpacking.model;

public class Login {

    private String userName;
    private String password;

    // Constructors.
    public Login(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public Login() {
    }

    @Override
    public String toString() {
        return "Login{" +
                "userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

    // Getters and Setters.
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
