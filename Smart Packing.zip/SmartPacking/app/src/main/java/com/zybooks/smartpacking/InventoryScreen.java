package com.zybooks.smartpacking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.zybooks.smartpacking.model.Item;
import com.zybooks.smartpacking.repo.ItemDatabase;
import java.util.ArrayList;
import java.util.List;


public class InventoryScreen extends AppCompatActivity {

    // References to UI widgets
    EditText newItemNameEditText,newItemQuantityEditText;
    Button addNewItemButton;
    Button item1, item2,item3, item4, item5, item6, item7, item8;

    ArrayList<Button> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_screen);
        setTitle("Inventory");

        // Initiate UI widget references.
        newItemNameEditText = findViewById(R.id.new_item_name_edit_text);
        newItemQuantityEditText = findViewById(R.id.new_item_quantity_edit_text);
        addNewItemButton = findViewById(R.id.add_new_item_button);

        // save items on screen into a variable.
        item1 = findViewById(R.id.item1);
        item2 = findViewById(R.id.item2);
        item3 = findViewById(R.id.item3);
        item4 = findViewById(R.id.item4);
        item5 = findViewById(R.id.item5);
        item6 = findViewById(R.id.item6);
        item7 = findViewById(R.id.item7);
        item8 = findViewById(R.id.item8);

        // Add all items to an array list.
        itemList = new ArrayList<>();
        itemList.add(item1);
        itemList.add(item2);
        itemList.add(item3);
        itemList.add(item4);
        itemList.add(item5);
        itemList.add(item6);
        itemList.add(item7);
        itemList.add(item8);

        // ItemDatabase reference
        ItemDatabase itemDatabase = new ItemDatabase(InventoryScreen.this);

        // update UI with items in database
        List<Item> databaseItemList = itemDatabase.readAllItems();

        // Set text for each button
        int i = 0;

        for (Item item: databaseItemList) {

            itemList.get(i).setText(databaseItemList.get(i).getItemName() + "\n" + databaseItemList.get(i).getItemQuantity());
            itemList.get(i).setEnabled(true);
            i++;

        }


        // TODO when add new item button is clicked, create new item.
        addNewItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // if the database is full, do not add items
                if(itemDatabase.getDatabaseSize() >= 8) {
                    Toast.makeText(InventoryScreen.this, "Database is full, try deleting an item", Toast.LENGTH_SHORT).show();
                }
                else{
                    try{
                        String itemName = newItemNameEditText.getText().toString();
                        int itemQuantity = Integer.parseInt(newItemQuantityEditText.getText().toString());

                        // create and insert new item in database
                        itemDatabase.createItem(itemName, itemQuantity);

                        // Set text for each button
                        for (Button item: itemList) {
                            if(item.isEnabled()){
                                continue;
                            }
                            else{
                                item.setText(itemName + "\n" + itemQuantity);
                                item.setEnabled(true);
                                break;
                            }
                        }
                        // print all items to logcat
                        itemDatabase.readAllItems();

                        Toast.makeText(InventoryScreen.this, "New Item created.", Toast.LENGTH_SHORT).show();
                    }
                    catch (Exception exception){
                        Toast.makeText(InventoryScreen.this, "ERROR: Item name/quantity blank or quantity is not an integer", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }

    public void goToItemScreen(View view){
        String buttonText = "";
        String itemName = "";
        int itemQuantity = 0;

        for (Button itemButton: itemList) {
            if (itemButton.getId() == view.getId()){
                // Extract and split button text into two variables, name and quantity
                buttonText = itemButton.getText().toString();
                String[] buttonItemQuantity = buttonText.split("\n");
                itemName = buttonItemQuantity[0];
                itemQuantity = Integer.parseInt(buttonItemQuantity[1]);
            }
        }

        Log.d("TESTING", "passing to itemscreen: " + itemName + " & " + itemQuantity);


        // Change screen to Item screen after clicking an item button.
        Intent i = new Intent(InventoryScreen.this, ItemScreen.class);
        i.putExtra("itemName", itemName);
        i.putExtra("itemQuantity", itemQuantity);
        startActivity(i);
    }

}