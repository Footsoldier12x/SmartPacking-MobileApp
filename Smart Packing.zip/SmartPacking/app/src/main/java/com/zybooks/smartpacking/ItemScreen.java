package com.zybooks.smartpacking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zybooks.smartpacking.repo.ItemDatabase;

public class ItemScreen extends AppCompatActivity {

    // References to UI widgets
    EditText itemNameEditText;
    EditText quantityEditText;
    Button updateItemAndQuantity;
    Button deleteItem;

    // ItemDatabase reference
    ItemDatabase itemDatabase = new ItemDatabase(ItemScreen.this);

    // Reference to inventory class
    InventoryScreen inventoryScreen = new InventoryScreen();

    // Store the initial value of the original item so that it can found in the database for updating
    String originalItemName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_screen);
        setTitle("Items");

        // Initialize references to all UI widgets
        itemNameEditText = findViewById(R.id.item_name_EditText);
        quantityEditText = findViewById(R.id.item_quantity_EditText);
        updateItemAndQuantity = findViewById(R.id.update_item_and_quantity_button);
        deleteItem = findViewById(R.id.item_delete_button);

        try {
            // TODO get item name and quantity from inventory screen
            Intent intent = getIntent();
            String itemName = intent.getStringExtra("itemName");
            String itemQuantity = String.valueOf(intent.getIntExtra("itemQuantity", 0));

            // Set UI values to match the item name and quantity sent from inventory screen.
            originalItemName = itemName;
            itemNameEditText.setText(itemName);
            quantityEditText.setText(itemQuantity);
        }
        catch (Exception exception){
            Toast.makeText(inventoryScreen, "Input Error, try again.", Toast.LENGTH_SHORT).show();
        }

        updateItemAndQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    String nameUpdate = itemNameEditText.getText().toString();
                    int quantityUpdate = Integer.parseInt(quantityEditText.getText().toString());

                    Log.d("TESTING", "calling updateItem");
                    boolean updateStatus = itemDatabase.updateItem(originalItemName,nameUpdate, quantityUpdate);

                    if (updateStatus){
                        Log.d("TESTING", "Updated " + nameUpdate);
                        Toast.makeText(ItemScreen.this, "Item " + nameUpdate + " updated", Toast.LENGTH_SHORT).show();

                        // Change screen to inventory screen after updating an item.
                        Intent i = new Intent(ItemScreen.this, InventoryScreen.class);
                        startActivity(i);
                    }
                    else{
                        Toast.makeText(ItemScreen.this, "Item not updated", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception exception){
                    Toast.makeText(ItemScreen.this, "ERROR: Item name/quantity blank or quantity is not an integer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 String deleteItemString = itemNameEditText.getText().toString();
                 Log.d("TESTING","call delete method in ItemDatabase");
                 boolean deleteStatus = itemDatabase.deleteItem(deleteItemString);

                 if (deleteStatus){
                     Log.d("TESTING", "Deleted " + deleteItemString);
                     Toast.makeText(ItemScreen.this, "Item " + deleteItemString + " deleted", Toast.LENGTH_SHORT).show();
                 }
                 else{
                     Toast.makeText(ItemScreen.this, "Item not deleted", Toast.LENGTH_SHORT).show();
                 }

                // Change screen to inventory screen after deleting an item.
                Intent i = new Intent(ItemScreen.this, InventoryScreen.class);
                startActivity(i);

            }
        });


    }


}