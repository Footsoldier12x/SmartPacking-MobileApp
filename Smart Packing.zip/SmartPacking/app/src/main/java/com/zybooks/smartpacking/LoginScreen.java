package com.zybooks.smartpacking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zybooks.smartpacking.model.Login;
import com.zybooks.smartpacking.repo.LoginDatabase;

public class LoginScreen extends AppCompatActivity {

    // References to UI widgets
    EditText userNameInput;
    EditText passwordInput;
    Button loginUserButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        setTitle("Log in");

        // Initiate UI widget references.
        userNameInput = findViewById(R.id.username_login_validation_edit_text);
        passwordInput = findViewById(R.id.password_login_validation_edit_text);
        loginUserButton = findViewById(R.id.login_validation_button);

        loginUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Check for input errors.
                try {
                    String user = userNameInput.getText().toString();
                    String password = passwordInput.getText().toString();

                    // LoginDatabase reference
                    LoginDatabase loginDatabase = new LoginDatabase(LoginScreen.this);

                    // Validate username and password by comparing them to database.
                    if (loginDatabase.readLogins(user, password)){
                        Toast.makeText(LoginScreen.this, "Welcome " + user, Toast.LENGTH_SHORT).show();

                        // Change screen to inventory screen upon successful user validation.
                        Intent i = new Intent(LoginScreen.this, InventoryScreen.class);
                        startActivity(i);
                    }
                    else{
                        Toast.makeText(LoginScreen.this, "Incorrect username or password. ", Toast.LENGTH_SHORT).show();
                    }

                }
                catch (Exception exception){
                    Toast.makeText(LoginScreen.this, "Please enter a valid username or password.", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }


}