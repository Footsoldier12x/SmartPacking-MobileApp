package com.zybooks.smartpacking.repo;

import static android.database.DatabaseUtils.queryNumEntries;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.zybooks.smartpacking.model.Item;

import java.util.ArrayList;

public class ItemDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "itemDatabase.db";
    private static final int VERSION = 1;

    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable{
        private static final String TABLE = "items";
        private static final String ITEM_NAME = "itemName";
        private static final String QUANTITY = "quantity";
    }

    // Create the item database table.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + ItemTable.TABLE + " (" + ItemTable.ITEM_NAME + " text, " + ItemTable.QUANTITY + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    public void createItem(String itemNameInput, int quantityInput){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        // Insert UI item name and quantity values
        values.put(ItemTable.ITEM_NAME, itemNameInput);
        values.put(ItemTable.QUANTITY, quantityInput);

        // If insert is successful, insert returns a positive number.
        long insertResult = db.insert(ItemTable.TABLE, null, values);

        if(insertResult == -1){
            Log.d("TESTING", "FAILED : No item inserted into database.");
        }
        else{
            Log.d("TESTING", "SUCCESS: New item inserted into database: " + itemNameInput + " & "+ quantityInput);
        }
        db.close();
    }

    public ArrayList readAllItems(){
        SQLiteDatabase db = getReadableDatabase();

        ArrayList<Item> itemList = new ArrayList<>();

        String sql = "select * from " + ItemTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        Log.d("TESTING", "printing all database results");

        if(cursor.moveToFirst()){
            do{
                // get values from UI Edit text widgets
                String name = cursor.getString(0);
                int quantity = cursor.getInt(1);
                Log.d("TESTING", name + ": " + quantity);

                // create new Item to insert into item list
                Item newItem = new Item(name, quantity);
                itemList.add(newItem);

            }while(cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return itemList;
    }

    public boolean updateItem(String originalItemName, String itemNameInput, int quantityInput){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // insert values into a contentValues object to insert into database.
        values.put(ItemTable.ITEM_NAME, itemNameInput);
        values.put(ItemTable.QUANTITY, quantityInput);

        Log.d("TESTING", "BEFORE DB.UPDATE");
        int updateStatus = db.update(ItemTable.TABLE, values, "itemName=?", new String[]{originalItemName});
        Log.d("TESTING", "AFTER DB.UPDATE");

        if (updateStatus == 0){
            db.close();
            return false;
        }else{
            db.close();
            return true;
        }
    }

    public boolean deleteItem(String deleteItemName){
        SQLiteDatabase db = getWritableDatabase();

        int deleteStatus = db.delete(ItemTable.TABLE, "itemName=?" , new String[]{deleteItemName});

        if (deleteStatus == 0){
            db.close();
            return false;
        }else{
            db.close();
            return true;
        }
    }

    public int getDatabaseSize(){
        SQLiteDatabase db = getReadableDatabase();
        long numRows = queryNumEntries(db, ItemTable.TABLE);

        return (int)numRows;
    }
}
