package com.zybooks.smartpacking;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.zybooks.smartpacking.repo.LoginDatabase;

public class CreateNewUser extends AppCompatActivity {

    // References to UI widgets
    EditText userNameInput;
    EditText passwordInput;
    EditText passwordConfirmInput;
    Button createNewUserButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_user);
        setTitle("Create New User");

        // Initiate UI widget references.
        userNameInput = findViewById(R.id.new_username_edit_text);
        passwordInput = findViewById(R.id.new_password_edit_text);
        passwordConfirmInput = findViewById(R.id.new_password_edit_text_confirm);
        createNewUserButton = findViewById(R.id.create_new_user_button);

        // When createNewUser button is clicked, create a new user and go to inventory screen.
        createNewUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Check for input errors.
                try {
                    String user = userNameInput.getText().toString();
                    String password = passwordInput.getText().toString();
                    String passwordConfirm = passwordConfirmInput.getText().toString();

                    // If passwords match, create new user.
                    if (password.compareTo(passwordConfirm) == 0){

                        // LoginDatabase reference
                        LoginDatabase loginDatabase = new LoginDatabase(CreateNewUser.this);
                        // Create new user
                        loginDatabase.createLogin(user, password);
                        Toast.makeText(CreateNewUser.this, "New user added.", Toast.LENGTH_SHORT).show();

                        // Change screen to inventory screen upon successful user creation.
                        Intent i = new Intent(CreateNewUser.this, InventoryScreen.class);
                        startActivity(i);

                    }
                    else{
                        Toast.makeText(CreateNewUser.this,"Passwords do not match.", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception exception){
                    Toast.makeText(CreateNewUser.this, "Please enter username or password.", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

}