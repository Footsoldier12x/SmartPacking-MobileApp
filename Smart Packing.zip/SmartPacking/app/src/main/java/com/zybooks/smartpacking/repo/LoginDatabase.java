package com.zybooks.smartpacking.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class LoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "loginDatabase.db";
    private static final int VERSION = 1;

    public LoginDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable{
        private static final String TABLE = "logins";
        private static final String USERNAME = "username";
        private static final String PASSWORD = "password";
    }

    // Create the login database table.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" + LoginTable.USERNAME + " text, " + LoginTable.PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    public void createLogin(String usernameInput, String passwordInput){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        // Insert UI username and passwords here
        values.put(LoginTable.USERNAME, usernameInput);
        values.put(LoginTable.PASSWORD, passwordInput);

        // If insert is successful, insert returns a positive number.
        long insertResult = db.insert(LoginTable.TABLE, null, values);

        if(insertResult == -1){
            Log.d("TESTING", "FAILED : No user inserted into database.");
        }
        else{
            Log.d("TESTING", "SUCCESS: New user inserted into database: " + usernameInput + " & "+ passwordInput);
        }
    }

    public boolean readLogins(String usernameInput, String passwordInput){
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{usernameInput});
        if(cursor.moveToFirst()) {
                String username = cursor.getString(0);
                String password = cursor.getString(1);

                // Validate user and password with inputs.
            Log.d("TESTING", "before validation");
            if ((username.equals(usernameInput)) && (password.equals(passwordInput)) ){
                Log.d("TESTING", "validated");
                cursor.close();
                return true;
            }
            else{
                Log.d("TESTING", "NOT validated");
                cursor.close();
                return false;
            }

        }
        else{
            cursor.close();
            Log.d("TESTING","username and password not found in database.");
            return false;
        }

    }

    /*

    private LoginDatabase(Context context){
        mLoginList = new ArrayList<>();
        Resources res = context.getResources();
        String[] userNames = res.getStringArray(R.array.userNames);
        String[] passwords  = res.getStringArray(R.array.passwords);
        for(int i = 0; i < userNames.length; i++){
            mLoginList.add(new Login(userNames[i],passwords[i] ));
        }
    }

    public void addLogin(Login LoginEntry){
        Log.d("TESTING", "addLogin ENTERED");
        mLoginList.add(LoginEntry);
        for (Login login:mLoginList) {
            Log.d("TESTING", login.getUserName());
            Log.d("TESTING", "addLogin ran ok");
        }
    }

    public List<String> getLogins(){
        List<String> userNameLogins = null;

        for (Login logins:mLoginList) {
            userNameLogins.add(logins.getUserName());
        }
        return userNameLogins;
    }

    */

}
