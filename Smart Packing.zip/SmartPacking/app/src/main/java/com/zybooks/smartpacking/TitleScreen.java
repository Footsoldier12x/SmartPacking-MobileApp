package com.zybooks.smartpacking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TitleScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_titlescreen);
        setTitle("Smart Packing");
    }

    public void GoToLoginScreen(View v){
        // launch login screen.
        Intent i = new Intent(this, LoginScreen.class);
        startActivity(i);
    }

    public void GoToCreateNewUserScreen(View v){
        // launch create new user screen.
        Intent i = new Intent(this, CreateNewUser.class);
        startActivity(i);
    }
}